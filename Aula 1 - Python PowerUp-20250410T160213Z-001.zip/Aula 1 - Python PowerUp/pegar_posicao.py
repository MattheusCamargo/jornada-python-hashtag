import time
import pyautogui

time.sleep(5)
print(pyautogui.position())

pyautogui.scroll(200)